import axios from 'axios';

export default axios.create({
    
    baseURL:'https://api.unsplash.com',
    headers:{ 
        Authorization://please write your key here like  'Client-ID my-key'  
    }

})
